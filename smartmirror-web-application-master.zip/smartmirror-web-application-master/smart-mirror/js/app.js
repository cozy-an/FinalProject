(function(angular) {
    'use strict';

    angular.module('SmartMirror', ['ngAnimate']);

}(window.angular));